using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Car : MonoBehaviour
{
    [SerializeField] private Vector3 vertical;
    private Transform trans;
    private bool check = true;
    private bool check1 = true;

    void Start()
    {
        trans = GetComponent<Transform>();
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.GetComponent<Wall>())
        {
            check = false;
        }

        if (collision.gameObject.GetComponent<Wall1>())
        {
            check1 = false;
        }
    }

    void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.GetComponent<Wall>())
        {
            check = true;
        }

        if (collision.gameObject.GetComponent<Wall1>())
        {
            check1 = true;
        }
    }

    void Update()
    {
        if (Input.GetKey(KeyCode.A) && check)
        {
            trans.position -= vertical;
        }

        if (Input.GetKey(KeyCode.D) && check1)
        {
            trans.position += vertical;
        }
    }
}
