using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OpponentCar : MonoBehaviour
{
    public float speed = 5f;

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Wall"))
        {
            Destroy(gameObject);
        }
    }

    void Update()
    {
        transform.Translate(Vector3.back * Random.Range(speed, 7f) * Time.deltaTime);
    }
}