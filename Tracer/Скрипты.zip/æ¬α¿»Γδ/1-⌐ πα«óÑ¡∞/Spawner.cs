using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner: MonoBehaviour
{
    public GameObject[] enemy;
    public Transform[] spawnPoint;

    public float timeBtwSpawns;

    void Update()
    {
        if (timeBtwSpawns <= 0)
        {
            Instantiate(enemy[Random.Range(0, enemy.Length)], spawnPoint[Random.Range(0, spawnPoint.Length)].transform.position, Quaternion.identity);
            timeBtwSpawns = Random.Range(0.5f, 2f);
        }

        else
        {
            timeBtwSpawns -= Time.deltaTime;
        }
    }
}