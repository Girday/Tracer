using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Timer : MonoBehaviour
{
    public TMP_Text text;
    public float timer = 0.01f;
    public string data;

    void Update()
    {
        timer += Time.deltaTime;
        data = timer.ToString();
        text.text = data;
    }
}
